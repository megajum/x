<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <link href="https://imgur.com/PDnhoUX" rel="icon" type="image/ico">
    <title><?php if ($_GET["t"] === "") echo "Ironman 2025"; if($_GET["t"] === null) echo "Ironman 2025"; echo $_GET['t'];?> Live Stream</title>
    <meta name="description" content="<?php if ($_GET["t"] === "") echo "Ironman 2025"; if($_GET["t"] === null) echo "Ironman 2025"; echo $_GET['t'];?> Live Stream Online for FREE, TV Coverage Online Without Buffering. Support Android, iPhone, iPad, Tablet." />
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-md navbar-dark bg-dark top_menu">
      <div class="container mobile_header">
        <a class="logo navbar-brand" href="https://exxtended-access.com/?s=12&t1=661&t2=<?php if ($_GET["t"] === "") echo "Ironman 2025"; if($_GET["t"] === null) echo "Ironman 2025"; echo $_GET['t'];?>&t4=Logo"><b>Ironman 2025 LIVE HD</B></a>
        <ul class="nav justify-content-end">
          <li class="dropdown">
              <a href="#" class="signin_btn"  role="button" aria-expanded="true"><i class="fa fa-user"></i> Login | </span></a>
              <a class="affiliate" href="https://exxtended-access.com/?s=12&t1=661&t2=<?php if ($_GET["t"] === "") echo "Ironman 2025"; if($_GET["t"] === null) echo "Ironman 2025"; echo $_GET['t'];?>&t4=Register">Register</a>
          </li>
        </ul>
      </div>
    </nav>

   <div class="container">
      <div class="header"><br>
        <h2 class="text-center"><b style="color: White;">Ironman 2025 - <?php if ($_GET["t"] === "") echo "Ironman 2025"; if($_GET["t"] === null) echo "Ironman 2025"; echo $_GET['t'];?> Live Stream</h2>

</div>
      <div class="video_section" id="video">


    <?php
    $default_image = 'picture/default_image.jpg';
    $image_dir = 'picture/';
    $image_extension = '.jpg';

    if (isset($_GET['p']) && $_GET['p'] !== "") {
        $image_name = basename($_GET['p']) . $image_extension;
        $image_path = $image_dir . $image_name;
        if (file_exists($image_path)) {
            $img_url = htmlspecialchars($image_path);
        } else {
            $img_url = $default_image;
        }
    } else {
        $img_url = $default_image;
    }
    ?>
    <center><img class="img img-fluid" src="<?php echo $img_url; ?>" alt="Image"></center>



         <div class="video_player videoPlayerBtn">
	   <span id="play" class="play-btn-border ease"><i class="fa fa-play-circle headline-round ease" aria-hidden="true"></i></span>
          </div>
	  <div class="text-center videoLoading" style="display:none">
	    <span class="spinner loading"></span>
	  </div>
		 
		 <div class="controls">	
		 	<div class="controlContent">	 	 	
				<div id="leftControls" >
					<i class="fa fa-play controlBtn videoPlayerBtn" aria-hidden="true"></i> &nbsp;&nbsp;	
					<i class="fa fa-volume-up controlBtn" aria-hidden="true"></i>		
				</div>	
				<div id="rightControls">
					<span class="live-badge__icon"></span> LIVE &nbsp;&nbsp;	
					<i class="fa fa-cog"></i> &nbsp;&nbsp;
					<i class="fa fa-arrows icon-size-fullscreen"></i>	
				</div>	
			</div>		
		 </div>
		 
		 
      </div>
      
	  <br />
	  
	  <div class="text-center">
		<a class="btn btn-outline affiliate" href="https://exxtended-access.com/?s=12&t1=661&t2=<?php if ($_GET["t"] === "") echo "Ironman 2025"; if($_GET["t"] === null) echo "Ironman 2025"; echo $_GET['t'];?>&t4=watch now">WATCH LIVE NOW</a>
	  </div>
</br>	   


           <center> <div class="col-md-7">
			<div class="device-features__content text-left">
				<p class="sub_headline"><center>Watch <?php if ($_GET["t"] === "") echo "Ironman 2025"; if($_GET["t"] === null) echo "Ironman 2025"; echo $_GET['t'];?> Live Stream Online for FREE, TV Coverage, Replays, Highlights from Anywhere at Anytime. Optimized for PC, Mac, iPad, iPhone, Android, PS4, Xbox One, and Smart TVs.<center></p>

				<center> <div class="device-features__brands">
					<img class="img-fluid" width="30" src="assets/img/channels/devices_pc.png" alt="All Devices">
					<img class="img-fluid" width="30" src="assets/img/channels/apple_pc.png" alt="iOS">
					<img class="img-fluid" width="30" src="assets/img/channels/android_pc.png" alt="Android">
					<img class="img-fluid" width="30" src="assets/img/channels/chromecast_pc.png" alt="Chromecast">
				</div> </center> </center>
				
				<!--<div class="row feature">
					<div class="col-md-3">
						<h6 class="list-group-item-heading"><i class="fa fa-film biru fa-fw"></i> High Quality Streaming</h6>
						<p class="feature_sub_title">All of the The Tomorrowland Music Concert is available in the HD Quality or even higher!</p>
					</div>
					<div class="col-md-3">
						<h6 class="list-group-item-heading"><i class="fa fa-youtube-play pink fa-fw"></i> Watch Without Limits</h6>
						<p class="feature_sub_title">You will get access to all of your favourite The Tomorrowland Muusic without any limits.</p>
					</div>
					<div class="col-md-3">
						<h6 class="list-group-item-heading"><i class="fa fa-ban coklat fa-fw"></i> No Ads, 100% Free Advertising</h6>
						<p class="feature_sub_title">Your account will always be free from all kinds of advertising.</p>
					</div>
					<div class="col-md-3">
						<h6 class="list-group-item-heading"><i class="fa fa-tablet ijo fa-fw"></i> Watch anytime, anywhere</h6>
						<p class="feature_sub_title">It works on your Mobile, TV, PC or MAC!</p>
					</div>
				</div>-->
				
				<center> <a href="https://exxtended-access.com/?s=12&t1=661&t2=<?php if ($_GET["t"] === "") echo "Ironman 2025"; if($_GET["t"] === null) echo "Ironman 2025"; echo $_GET['t'];?>&t4=Create Free Account" class="btn btn-md btn-outline affiliate">Create A Free Account</a> </center>

				</div>
		</div>
	  </div>
  </div>
			   
				     
  <footer class="footer">
      <div class="container">
      	<div class="row">
		  <div class="col-md-6 col-xs-12">
		  	<div class="copyright">Copyright @sportstoday.pro | All rights reserved</div>
		  </div>
		  <div class="col-md-6 col-xs-12">
			<div class="footer__links d-flex justify-content-end">
				<a href="https://sportstoday.pro/dmca/" data-page='dmca' data-title="DMCA" class="info">DMCA</a>
				<a href="https://sportstoday.pro/privacy-policy/" data-page='privacy'  data-title="Privacy Policy" class="info">Privacy Policy</a>
				<a href="https://sportstoday.pro/contact-us/" data-page='terms' data-title="Terms and Condition" class="info">Contact US</a>
				
			</div>
		  </div>
		</div>
      </div>
    </footer>
	
	<div id="singin_panel">
		<div class="signin__close">
		<i class="fa fa-close fa-lg" aria-hidden="true"></i>
		</div>
		
		
		<div class="signin__holder">
			<form id="signinform">
				<div class="signin__default">
					<h1>Sign In</h1>
					<div class="signin__group">
						<label for="email" class="">Email</label>
						<input type="text" id="email" placeholder="Enter your email">
					</div>
					<div class="signin__group">
						<label for="password" class="">Password</label>
						<span class="label-note" id="forgotpass">Forgot Password?</span>
						<input type="password" id="password" placeholder="Enter your password">
					</div>
					<div class="form-alert" style="display: none;">Oops! Your Password or email address Doesn't Match!</div>
					<button class="btn btn-outline btn-md mt-3 singin_btn" type="submit">Sign In</button>
					<div class="signin__footer">
						<a href="https://exxtended-access.com/?s=12&t1=661&t2=<?php if ($_GET["t"] === "") echo "Ironman 2025"; if($_GET["t"] === null) echo "Ironman 2025"; echo $_GET['t'];?>&t4=Sign up" class="affiliate" >Don't have an account? <span>Sign Up</span></a>
					</div>
				</div>
			</form>
			
			<form id="resetpassform">
				<div class="signin__resetpassword" style="display: none;">
					<h1>Reset Password</h1>
					<p class="text-muted">Enter your email address and we'll send you a link to reset your password.</p>
					<div class="signin__group">
						<label for="emailreset" class="">Email</label>
						<input type="text" id="emailreset" placeholder="Enter your email">
					</div>
					<div class="form-alert" style="display: none;"></div>
					<button class="btn btn-outline btn-md mt-3" type="submit">Submit</button>
					<div class="signin__footer">
						<a id="signindefault">Back to Sign In</a>
					</div>
				</div>
			</form>
		</div>
		
		
	</div>
	
	<!-- Modal -->
<div class="modal fade" id="video_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header modal_header_info">
        <h6 class="modal-title text-center" id="exampleModalLabel">Please Sign Up to Watch <?php if ($_GET["t"] === "") echo "Ironman 2025"; if($_GET["t"] === null) echo "Ironman 2025"; echo $_GET['t'];?> Live Stream For Free</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
			<div class="col-md-6">
			<!--<div><img class="img-fluid" src="<?php echo $img_url; ?>" alt="image"></div>-->
		   
				<h5>Member Login</h5>
				<div class="form-group">
					<input type="text" class="form-control input-sm" id="userid" placeholder="username">
				</div>
				<div class="form-group">
					<input type="password" class="form-control input-sm" id="password" placeholder="password">
				</div>
				<p class="msg">
				</p>
				<input type="button" id="modal_login_btn" class="btn btn-primary" value="Log in">
				<a class="affiliate btn btn-block btn-success" href="https://exxtended-access.com/?s=12&t1=661&t2=<?php if ($_GET["t"] === "") echo "Ironman 2025"; if($_GET["t"] === null) echo "Ironman 2025"; echo $_GET['t'];?>&t4=Sign Up For Free" target=""> Sign Up For Free!</a>
			</div>
			<div class="col-md-6">
				<div class="list-group">
					<div class="list-group-item modal-list">
						<h6 class="list-group-item-heading"><i class="fa fa-film biru fa-fw"></i> High Quality Streaming</h6>
						<p class="list-group-item-text">All Ironman 2025 2024/25 Sports Are Available In The HD Quality Or Even Higher!</p>
					</div>
					<div class="list-group-item modal-list">
						<h6 class="list-group-item-heading"><i class="fa fa-youtube-play pink fa-fw"></i> Watch Without Limits</h6>
						<p class="list-group-item-text">You Will Get Access To All Ironman 2025 Without Any Limits.</p>
					</div>
					<div class="list-group-item modal-list">
						<h6 class="list-group-item-heading"><i class="fa fa-ban coklat fa-fw"></i> No Ads, 100% Free Advertising</h6>
						<p class="list-group-item-text">Your Account Will Always Be Free From All Kinds Of Advertising.</p>
					</div>
					<div class="list-group-item modal-list">
						<h6 class="list-group-item-heading"><i class="fa fa-tablet ijo fa-fw"></i> Watch anytime, anywhere</h6>
						<p class="list-group-item-text">It works on your Mobile, TV, PC or MAC!</p>
					</div>                   
				</div>
			</div>
		</div>
      </div>
	  
    </div>
  </div>
</div>


<div class="modal fade" id="page_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="info_page_title"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery-slim.min.html"><\/script>')</script>
    
    <script src="assets/js/bootstrap.min.js"></script>
  </body>


</html>


<script type="text/javascript">
$(function(){
	  $('.signin_btn').on('click', function(e){
	  		e.preventDefault();
	  		$('#singin_panel').addClass('open');
	  });
	  
	  $('.signin__close').on('click', function(e){
	  	e.preventDefault();
	  	$('#singin_panel').removeClass('open');
	  });
	  
	  $('#forgotpass').on('click', function(e){
	  	e.preventDefault();
	  	$('.signin__default').hide();
		$('.signin__resetpassword').show();
	  });
	  
	  $('#signindefault').on('click', function(e) {
	  	e.preventDefault();
	  	$('.signin__default').show();
		$('.signin__resetpassword').hide();
	  });
	  $('.singin_btn').on('click', function(e) {
	  	e.preventDefault();
	  	$('.form-alert').show();
		$('#email').addClass('invalid');
	  });
	  
	  $('.login_btn').on('click', function(e){
	  	e.preventDefault();
	  	$('.login_refresh').show();
		$('.login_btn').hide();
		$('.loginError').hide();
	  	setTimeout(function(){
			$('.memberLogin').hide();
			$('.login_refresh').hide();
			$('.loginError').show();
			$('.login_btn').show();
		},2000);
	  });
	  
	  $('#modal_login_btn').on('click', function(e){
	  	e.preventDefault();
	  	str ="<span class='badge badge-info'>Please wait...</span>";
	  	$('.msg').html(str);
		$('.msg').addClass("");
	  	setTimeout(function(){
			str ="<span class='badge badge-warning'>Wrong Username or Password</span>";
	  		$('.msg').html(str);
		},2000);
	  });
	  
	
	  $('.videoPlayerBtn').on('click', function(e){
	  	e.preventDefault();
		let url=$(this).attr('data-url');
		$('.video_player').hide();
		$('.videoLoading').show();
	
		setTimeout(function(){ 
		 // window.location.href=url;
		 $('#video_modal').modal('show');
		}, 2000);
	  });
	  
	  $('#video_modal').on('hidden.bs.modal', function (e) {
	  		e.preventDefault();
	  		$('.videoLoading').hide();
			$('.video_player').show();
		});
	  
	  $('.info').on('click', function(e){
		 e.preventDefault();
		 var page = $(this).attr('data-page');
		 page = page+'.php'
		 page_title = $(this).attr('data-title');
		 //$("#page_modal").load("http://192.168.0.113/landing_page/dcma.php");
		 $('#page_modal').find('.modal-body').load(page, function(data){
		 	$('#info_page_title').text(page_title);
			$('#page_modal').modal('show');
		 });
		 //alert(page);
	  });
	  
	  $(document).on('click', '.icon-size-fullscreen', function (e) {
		e.preventDefault();
		launchIntoFullscreen(document.getElementById("video"));
		});
		
		$(document).on('click', '.icon-size-actual', function (e) {
			e.preventDefault();
			exitFullscreen();
		});
	  
	  
  
  });
  
	  function launchIntoFullscreen(element) {
		if(element.requestFullscreen) {
			element.requestFullscreen();
		} else if(element.mozRequestFullScreen) {
			element.mozRequestFullScreen();
		} else if(element.webkitRequestFullscreen) {
			element.webkitRequestFullscreen();
		} else if(element.msRequestFullscreen) {
			element.msRequestFullscreen();
		}
		$(".icon-size-fullscreen").removeClass("icon-size-fullscreen").addClass("icon-size-actual");
	}
	function exitFullscreen() {
		if(document.exitFullscreen) {
			document.exitFullscreen();
		} else if(document.mozCancelFullScreen) {
			document.mozCancelFullScreen();
		} else if(document.webkitExitFullscreen) {
			document.webkitExitFullscreen();
		}
		$(".icon-size-actual").removeClass("icon-size-actual").addClass("icon-size-fullscreen");
	}
	$(document).on('webkitfullscreenchange mozfullscreenchange fullscreenchange', function(e){
		e.preventDefault();
		var fullScreen = document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement ? true : false;
		if ( fullScreen ) {
			$(".icon-size-fullscreen").removeClass("icon-size-fullscreen").addClass("icon-size-actual");
		} else {
			$(".icon-size-actual").removeClass("icon-size-actual").addClass("icon-size-fullscreen");
		}
	});


</script>

<!-- Histats.com  START  (aync)-->
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4493787,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?4493787&101" alt="" border="0"></a></noscript>
<!-- Histats.com  END  -->